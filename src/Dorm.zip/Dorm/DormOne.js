import React, {useEffect, useState} from 'react';
import {useParams} from 'react-router-dom';
import axios from 'axios';
import {Button, Col, Container, Row, Table} from 'react-bootstrap';

const DormDetails = () => {
    const [dorm, setDorm] = useState(null);
    const { id } = useParams();

    useEffect(() => { // 여기 문제.




        const fetchDormDetails = async () => {
            try {
                const response = await axios.get(`http://localhost:8080/dorms/${id}`); //템플럿 리터럴  백틱으로 문자열 감싸서 삽입.
                console.log("API 응답 확인용");

                if (response.data.result === 'success') {
                    setDorm(response.data);
                } else {
                    console.error('Failed to fetch dorm details');
                }
            } catch (error) {
                console.error('Error fetching dorm details:', error);
            }
        };

        fetchDormDetails();
    }, [id]); // id가 변경될 때마다 useEffect 실행


    if (!dorm) {
        return <div>Loading.......</div>
    }


    return (
        <Container>
            <Row className="justify-content-center">
                <Col xs md lg={8} style={{ backgroundColor: 'lightblue' }}>
                    <h2 className="text-center my-4">기숙사 상세 정보</h2>
                    <Table striped bordered hover>
                        <tbody>
                        <tr>
                            <td>이름 :</td>
                            <td>{dorm.name}</td>
                        </tr>
                        <tr>
                            <td>설명 :</td>
                            <td>{dorm.description}</td>
                        </tr>
                        <tr>
                            <td>연락처 :</td>
                            <td>{dorm.contactNum}</td>
                        </tr>
                        <tr>
                            <td>도시 :</td>
                            <td>{dorm.city}</td>
                        </tr>
                        <tr>
                            <td>구/읍 :</td>
                            <td>{dorm.town}</td>
                        </tr>
                        <tr>
                            <td>주소 :</td>
                            <td>{dorm.address}</td>
                        </tr>
                        {/*백엔드에 있는 값들 갖고 오는건데 타운,넘버 안됨. */}
                        </tbody>
                    </Table>
                    <div className="text-center my-4">
                        <Button onClick={() => window.history.back()}>뒤로 가기</Button>
                    </div>
                </Col>
            </Row>
        </Container>
    );
};

export default DormDetails;